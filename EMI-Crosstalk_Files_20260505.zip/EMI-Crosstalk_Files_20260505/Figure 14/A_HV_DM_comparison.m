% Author: Bruce Lee, Harvey Liu, Katherine A. Kim
% National Taiwan Unverisity, EE Department, PEARS Lab
% Date: 2025
% Description: EMI measured and simulation data plotting
sim = readmatrix("HV DM_simulated.xlsx");
mea = readmatrix('HV DM_measured.csv');
f = mea(:,1);                                
signal = mea(:,2);
f_sim = sim(:,1);
signal_sim = sim(:,2);
signal_sim = signal_sim + 120;


figureHandle = figure;
set(figureHandle, 'Position', [100, 100, 800,500]);
semilogx(f_sim,signal_sim, 'LineWidth',1.5);
hold on
semilogx(f,signal, "LineWidth",1.5);
grid on

xlim([150e3,30e6]);
ylim([-10,60])
s = legend('Simulation', 'Experiment');
set(s, 'FontSize', 16, 'fontweight', 'bold');

xlabel('Frequency (Hz)', 'FontSize',20, 'FontWeight','bold');
ylabel('Magnitude (dBuV)', 'FontSize', 20, 'FontWeight','bold');
set(gca, 'FontSize', 20, 'fontweight', 'bold');

signal_sim_interp = interp1(f_sim, signal_sim, f, 'linear', 'extrap');


