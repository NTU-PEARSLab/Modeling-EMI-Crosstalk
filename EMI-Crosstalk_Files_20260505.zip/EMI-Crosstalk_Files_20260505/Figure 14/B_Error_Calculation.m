% Author: Alfred Edric Susanto, Katherine A. Kim
% National Taiwan Unverisity, EE Department, PEARS Lab
% Date: 2026-04-21
% Description: EMI ENVELOPE ANALYSIS: PEAK ERROR CALCULATION. 
% This scripts calulcates the EMI spectrum errors between the  
% peak value of the measured and simulated values

% Note: Run "A_HV_DM_comparison.m" first before running this code

% 1. Find the peaks on the simulated system
[~, idx_s] = findpeaks(signal_sim_interp, 'MinPeakHeight', 29);
idx_s(226) = [];

% 2. Turn the peaks from dB to magnitude for calculation purposes
pk_s = db2mag(signal_sim_interp(idx_s));

% 3. Find the range between the indices of peak k and k+1, then find the 
% mid point of the distance between them and make sure that it is rounded 
% to a whole number and then add that number to the starting index of each 
% pair.
range = ceil((idx_s(2:end)-idx_s(1:end-1))./2)+idx_s(1:end-1);

% 4. Get the values for the max experimental values on each window
% Initial Value for the Vector pk_m taking highest value between the 
% indices of the start until range(1)
pk_m(1) = max(signal(1:range(1)));

% Value for the Vector from the second list the end-1
for k=1:length(range)-1
    pk_m(k+1) = max(signal(range(k):range(k+1)));
end

% Final Value for the Vector
pk_m(k+2) = max(signal(range(k+1):end));

% Transpose the Vector, so that it has the same dimension as pk_s
pk_m = transpose(db2mag(pk_m));

% 6. Accuracy checker
diff = abs(pk_m-pk_s)./pk_s;
accuracy_percentage = (mean(diff)) * 100;
fprintf('Average Model Accuracy: %.2f%%\n', accuracy_percentage);

% Plotting
% 1. Create vectors the same size as the frequency data
staircase_mea = zeros(size(f));
staircase_sim = zeros(size(f));

% 2. Define the window boundaries using the existing logic
% We force 'range' to be a row to avoid errors
windows = [1, range(:)', length(f)];

% 3. Fill the vectors using the pre-calculated peaks
% We convert pk_s and pk_m back to dB for the plot
pk_s_db = mag2db(pk_s); 
pk_m_db = mag2db(pk_m);

for k = 1:length(windows)-1
    idx_win = windows(k):windows(k+1);
    
    % Assign the pre-calculated peak to this entire window
    staircase_sim(idx_win) = pk_s_db(k);
    staircase_mea(idx_win) = pk_m_db(k);
end

% 4. Create the final plot
figure('Position', [100, 100, 800, 500]);
semilogx(f, staircase_sim, 'b', 'LineWidth', 2); hold on;
semilogx(f, staircase_mea, 'r', 'LineWidth', 2);

% Formatting
grid on; xlim([150e3, 30e6]); ylim([-10, 60]);
xlabel('Frequency (Hz)', 'FontSize', 16, 'FontWeight', 'bold');
ylabel('Magnitude (dBuV)', 'FontSize', 16, 'FontWeight', 'bold');
legend('Simulated', 'Measured', 'FontSize', 14);
title('Peak Values');
set(gca, 'FontSize', 14, 'FontWeight', 'bold');
