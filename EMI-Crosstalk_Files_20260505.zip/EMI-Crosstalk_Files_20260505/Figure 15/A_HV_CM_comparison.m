% Author: Bruce Lee, Harvey Liu, Katherine A. Kim
% National Taiwan Unverisity, EE Department, PEARS Lab
% Date: 2025
% Description: EMI measured and simulation data plotting
mea = readmatrix('HV_CM_measured.csv');
f = mea(:,1);                                
signal = mea(:,2);
sim = readmatrix('HV_CM_simulated.xlsx');
f_sim = sim(:,1);
signal_sim = sim(:,2);
signal_sim = signal_sim+120;

figureHandle = figure;
set(figureHandle, 'Position', [100, 100, 800,500]);
semilogx(f_sim,signal_sim, 'LineWidth',1.5);

hold on
semilogx(f,signal, "LineWidth",1.5);
grid on
xlabel('Frequency in Hz', 'FontSize',20, 'FontWeight','bold');
ylabel('Magnitude in dBuV', 'FontSize', 20, 'FontWeight','bold');
xlim([150e3,30e6]);
ylim([-60,80]);
s = legend('Simulation', 'Experiment');
set(s, 'FontSize', 16, 'fontweight', 'bold');
xlabel('Frequency (Hz)', 'FontSize',20, 'FontWeight','bold');
ylabel('Magnitude (dBuV)', 'FontSize', 20, 'FontWeight','bold');
set(gca, 'FontSize', 20, 'fontweight', 'bold');

% To align the data with Linear interpolation with extrapolation for 
% out-of-range frequencies
signal_sim_interp = interp1(f_sim, signal_sim, f, 'linear', 'extrap');